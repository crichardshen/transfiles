import java.util.Arrays;
import java.util.concurrent.TimeUnit;

public class MyRunnable implements Runnable{
    private int sleepingTimeout = 0;
    private String threadDefinedName = "";
    private Thread currentThreadAssigned = null;

    public Thread getCurrentThreadAssigned() {
        if(this.currentThreadAssigned == null){
            return null;
        }
        return currentThreadAssigned;
    }

    public MyRunnable(int timeOut, String threadName){
        this.sleepingTimeout = timeOut;
        this.threadDefinedName = threadName;
    }
    public void run() {
        this.currentThreadAssigned = Thread.currentThread();
        try {
            while(!Thread.currentThread().isInterrupted()){
                System.out.println("线程编号 " + Thread.currentThread().getName() + " 正在运行");
                TimeUnit.SECONDS.sleep(sleepingTimeout);
            }
        } catch (InterruptedException e) {
            System.out.println(Thread.currentThread().getName() + " 接受中断，结束线程~~");
            return;
        }
    }
}
