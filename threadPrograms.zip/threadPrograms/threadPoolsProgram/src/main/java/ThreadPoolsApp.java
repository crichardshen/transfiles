import java.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.*;


public class ThreadPoolsApp {
    public static void main(String[] args) {
        BlockingQueue<Runnable> myLinkedRunnables = new LinkedBlockingDeque<>(10);
        List<MyRunnable> myRunnableList = new ArrayList<>();

        //线程池
        ThreadPoolExecutor service = new ThreadPoolExecutor(
                10,
                10,
                0L,
                TimeUnit.MILLISECONDS,
                myLinkedRunnables);

        //创建任务myRunnable
        for (int i = 0; i < 9 ; i++) {
            MyRunnable myRunnable = new MyRunnable(100,"threadName-"+String.valueOf(i));
            myRunnableList.add(myRunnable);
            service.execute(myRunnable);
        }

        //主要通过设置线程的interrupt属性来进行判断是否"中断"线程
        //将runnable对象保留在列表中，在适当的时候通过设置interrupt属性来中断（这个属性要在线程内配合while(!Thread.currentThread().isInterrupted())使用）
        myRunnableList.get(0).getCurrentThreadAssigned().interrupt();

        //直接返回java内建的Future对象，使用起cancel方法来打断线程，cancel的实质也是使用interrupt
        Future<?> onetimetask = service.submit(new MyRunnable(100, "onetimetask"));
        onetimetask.cancel(true);



    }
}

